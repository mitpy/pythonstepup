def findMul2(n1,n2):
    print(n1*n2)
