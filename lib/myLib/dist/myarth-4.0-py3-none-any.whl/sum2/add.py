def sumOfTwo(n1,n2):
    print(n1+n2)